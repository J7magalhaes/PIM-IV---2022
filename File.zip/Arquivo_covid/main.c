#include <stdio.h>
#include <stdlib.h>

int main(void)
{
  FILE *arquivo_covid;
  arquivo_covid = fopen("arquivo.txt", "a");

  fclose(arquivo_covid);

  printf("O arquivo foi criado com sucesso!");

  system("pause");
  return(0);
}
